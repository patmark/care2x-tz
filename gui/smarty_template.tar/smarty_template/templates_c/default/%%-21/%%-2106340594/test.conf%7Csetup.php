<?php $_config_vars = array (
  'cutoff_size' => '40',
  'bold' => true,
); ?>