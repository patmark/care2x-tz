<?php /* Smarty version 2.6.22, created on 2012-08-15 18:28:48
         compiled from registration_admission/reg_row.tpl */ ?>
<tr>
  <td class="reg_item" <?php echo $this->_tpl_vars['sColSpan1']; ?>
><?php echo $this->_tpl_vars['sItem']; ?>
</td>
  <td class="reg_input" <?php echo $this->_tpl_vars['sColSpan2']; ?>
><?php echo $this->_tpl_vars['sInput']; ?>
</td>
</tr>