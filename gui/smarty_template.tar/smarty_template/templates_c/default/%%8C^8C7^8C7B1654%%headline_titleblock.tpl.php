<?php /* Smarty version 2.6.22, created on 2012-08-11 20:12:29
         compiled from news/headline_titleblock.tpl */ ?>

			<!--    The title text bouding box   -->
			<table border=0 bgcolor=#cfcfcf cellpadding=1 cellspacing=0 width="100%">
				<tr>
					<td>

						<table border=0 bgcolor=#ffffff cellpadding=1 cellspacing=0 width="100%">
							<tr>
								<td>
									<font size=6 color=#800000>
									<b><?php echo $this->_tpl_vars['LDHeadline']; ?>
</b>
									</font>
								</td>
							</tr>
						</table>

					</td>
				</tr>
			</table>