<?php /* Smarty version 2.6.22, created on 2011-08-29 21:46:43
         compiled from or/select_dept.tpl */ ?>

<ul>
<table border=0>
	<tr>
		<td>
			<?php echo $this->_tpl_vars['sMascotImg']; ?>

		</td>

		<td colspan=4 class="prompt">
			<center>
			<?php echo $this->_tpl_vars['LDPlsSelectDept']; ?>

			</center>
		</td>
	</tr>
</table>

<table  cellpadding="2" cellspacing=0 border="0">
	<?php echo $this->_tpl_vars['sDeptRows']; ?>

</table>

<p>
<?php echo $this->_tpl_vars['sBackLink']; ?>

</ul>
<p>