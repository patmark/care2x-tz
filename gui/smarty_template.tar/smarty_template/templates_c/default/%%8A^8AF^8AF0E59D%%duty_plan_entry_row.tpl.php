<?php /* Smarty version 2.6.22, created on 2011-08-29 21:44:51
         compiled from common/duty_plan_entry_row.tpl */ ?>

<tr <?php echo $this->_tpl_vars['sRowClass']; ?>
>
	<td><?php echo $this->_tpl_vars['iDayNr']; ?>
</td>
	<td><?php echo $this->_tpl_vars['LDShortDay']; ?>
</td>
	<td><nobr><?php echo $this->_tpl_vars['sIcon1']; ?>
&nbsp<?php echo $this->_tpl_vars['sInput1']; ?>
</nobr></td>
	<td><?php echo $this->_tpl_vars['sPopWin1']; ?>
</td>
	<td><nobr><?php echo $this->_tpl_vars['sIcon2']; ?>
&nbsp<?php echo $this->_tpl_vars['sInput2']; ?>
</nobr></td>
	<td><?php echo $this->_tpl_vars['sPopWin2']; ?>
</td>
<td><nobr><?php echo $this->_tpl_vars['sIcon3']; ?>
&nbsp<?php echo $this->_tpl_vars['sInput3']; ?>
</nobr></td>
	<td><?php echo $this->_tpl_vars['sPopWin3']; ?>
</td>
</tr>
