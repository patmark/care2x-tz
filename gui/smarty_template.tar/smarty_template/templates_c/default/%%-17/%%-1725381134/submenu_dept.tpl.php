<?php /* Smarty version 2.6.0, created on 2009-03-03 18:52:08
         compiled from ambulatory/submenu_dept.tpl */ ?>
			<TABLE cellSpacing=0  width=100% class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 width=100%  cellPadding=3>
					<TBODY class="submenu">

						<TR>
							<TD colspan=2 class="submenu_title"><?php echo $this->_tpl_vars['sBlockTitle']; ?>
</TD>
						</tr>

						<TR>
							<TD width=25 align=center><?php echo $this->_tpl_vars['sApptIcon']; ?>
</TD>
							<TD class="submenu_item"><nobr><?php echo $this->_tpl_vars['sApptLink']; ?>
</nobr></TD>
						</tr>

						<TR>
							<TD width=25 align=center><?php echo $this->_tpl_vars['sOutPatientIcon']; ?>
</TD>
							<TD class="submenu_item"><nobr><?php echo $this->_tpl_vars['sOutPatientLink']; ?>
</nobr></TD>
						</tr>

						<TR>
							<TD width=25 align=center><?php echo $this->_tpl_vars['sPendReqIcon']; ?>
</TD>
							<TD class="submenu_item"><nobr><?php echo $this->_tpl_vars['sPendReqLink']; ?>
</nobr></TD>
						</tr>

					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE>

