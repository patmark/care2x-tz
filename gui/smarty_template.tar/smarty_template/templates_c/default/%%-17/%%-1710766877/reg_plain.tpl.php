<?php /* Smarty version 2.6.0, created on 2009-01-13 08:42:50
         compiled from registration_admission/reg_plain.tpl */ ?>
<table width="100%" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "registration_admission/reg_tabs.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></td>
    </tr>

    <tr>
      <td>
			<?php echo $this->_tpl_vars['sMainDataBlock']; ?>

	  </td>
    </tr>
  </tbody>
</table>