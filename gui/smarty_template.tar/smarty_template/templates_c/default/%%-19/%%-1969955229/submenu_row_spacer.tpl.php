<?php /* Smarty version 2.6.0, created on 2009-03-03 18:52:49
         compiled from common/submenu_row_spacer.tpl */ ?>
<TR  height=1>
	<TD colSpan=3 class="vspace"><IMG height=1 src="../../gui/img/common/default/pixel.gif" width=5></TD>
</TR>