<?php /* Smarty version 2.6.0, created on 2009-01-13 00:55:06
         compiled from common/frameset_ltr.tpl */ ?>

<frameset cols="<?php echo $this->_tpl_vars['gui_frame_left_nav_width']; ?>
,*" border="<?php echo $this->_tpl_vars['gui_frame_left_nav_border']; ?>
">
	<FRAME  NAME = "STARTPAGE" <?php echo $this->_tpl_vars['sStartFrameSource']; ?>
 MARGINHEIGHT="5"	MARGINWIDTH  ="5" SCROLLING="auto" >
	<FRAME NAME = "CONTENTS" <?php echo $this->_tpl_vars['sContentsFrameSource']; ?>
>
</frameset>