<?php /* Smarty version 2.6.22, created on 2010-12-10 08:46:32
         compiled from laboratory/chemlab_data_results_graph.tpl */ ?>

<ul>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "laboratory/patient_data_basic.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</ul>

<?php echo $this->_tpl_vars['sLabResultsGraphTable']; ?>


<ul>
	<?php echo $this->_tpl_vars['sClose']; ?>

</ul>