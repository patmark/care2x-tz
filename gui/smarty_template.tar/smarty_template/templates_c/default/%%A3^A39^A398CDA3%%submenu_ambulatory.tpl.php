<?php /* Smarty version 2.6.22, created on 2013-11-22 10:22:04
         compiled from ambulatory/submenu_ambulatory.tpl */ ?>
<blockquote>
<table border=0 cellpadding=5>

  <tr>
    <td colspan=2>
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "ambulatory/submenu_generic.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	</td>
  </tr>
  
    <tr>
    <td width=50%>
	</td>
    <td width=50%>
	</td>
  </tr>
<!--
	<tr>
    <td width=50%>
		<?php echo $this->_tpl_vars['s3SubMenu']; ?>

	</td>
    <td width=50%>
		<?php echo $this->_tpl_vars['s4SubMenu']; ?>

	</td>
  </tr>
-->
	<tr>
    <td width=50%>
	</td>
    <td width=50%>
	</td>
  </tr>
	<tr>
    <td width=50%>
	</td>
    <td width=50%>
	</td>
  </tr>
	<tr>
    <td width=50%>
	</td>
    <td width=50%>
	</td>
  </tr>
  <!--
	<tr>
    <td width=50%>
		<?php echo $this->_tpl_vars['s2SubMenu']; ?>

	</td>
    <td width=50%>
		<?php echo $this->_tpl_vars['s12SubMenu']; ?>

	</td>
  </tr>-->
</table>
<a href="<?php echo $this->_tpl_vars['breakfile']; ?>
"><img <?php echo $this->_tpl_vars['gifClose2']; ?>
 alt="<?php echo $this->_tpl_vars['LDCloseAlt']; ?>
" <?php echo $this->_tpl_vars['dhtml']; ?>
></a>
</blockquote>