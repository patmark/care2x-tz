<?php /* Smarty version 2.6.0, created on 2009-01-13 00:56:53
         compiled from common/footer.tpl */ ?>
<!--  <?php echo $this->_tpl_vars['SmartyLogo']; ?>
 -->
</BODY>
</HTML>