<?php /* Smarty version 2.6.22, created on 2009-02-13 21:13:24
         compiled from products/ordering_header.tpl */ ?>

<table border=0 width=100%>
  <tr>
    <td align=center valign=top width=50% class="prompt"><b><?php echo $this->_tpl_vars['LDBasket']; ?>
</b></td>
    <td align=center valign=top class="prompt"><?php echo $this->_tpl_vars['LDCatalog']; ?>
</td>
	 <td align=right valign=top><nobr><a href="<?php echo $this->_tpl_vars['pbHelp']; ?>
"><img <?php echo $this->_tpl_vars['gifHilfeR']; ?>
 <?php echo $this->_tpl_vars['dhtml']; ?>
></a><a href="<?php echo $this->_tpl_vars['breakfile']; ?>
" target=_parent><img <?php echo $this->_tpl_vars['gifClose2']; ?>

	<?php echo $this->_tpl_vars['dhtml']; ?>
></a></nobr></td>
  </font></tr>
</table>