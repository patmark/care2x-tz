<?php /* Smarty version 2.6.22, created on 2012-08-18 22:15:19
         compiled from common/submenu_row.tpl */ ?>
<TR>
	<td align=center><?php echo $this->_tpl_vars['sIconImg']; ?>
</td>
	<TD class="submenu_item"><nobr><?php echo $this->_tpl_vars['sSubMenuItem']; ?>
</nobr></TD>
	<TD><?php echo $this->_tpl_vars['sSubMenuText']; ?>
</TD>
</tr>