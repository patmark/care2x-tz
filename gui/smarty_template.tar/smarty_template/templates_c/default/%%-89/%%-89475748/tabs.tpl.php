<?php /* Smarty version 2.6.0, created on 2009-03-03 19:18:11
         compiled from medocs/tabs.tpl */ ?>
<table width="100%" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td height=24><?php echo $this->_tpl_vars['pbNew'];  echo $this->_tpl_vars['pbSearch']; ?>
</td>
    </tr>
    <tr>
      <td class="adm_div"><img src="p.gif" border=0 width=1 height=5><?php echo $this->_tpl_vars['sSubTitle'];  echo $this->_tpl_vars['sWarnText']; ?>
</td>
    </tr>
  </tbody>
</table>