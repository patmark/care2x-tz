<?php /* Smarty version 2.6.0, created on 2009-03-03 18:52:49
         compiled from common/submenu_row.tpl */ ?>
<TR>
	<td align=center><?php echo $this->_tpl_vars['sIconImg']; ?>
</td>
	<TD class="submenu_item"><nobr><?php echo $this->_tpl_vars['sSubMenuItem']; ?>
</nobr></TD>
	<TD><?php echo $this->_tpl_vars['sSubMenuText']; ?>
</TD>
</tr>