<?php /* Smarty version 2.6.22, created on 2012-08-11 23:22:31
         compiled from laboratory/submenu_lab.tpl */ ?>
			<blockquote>
			<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">
						<TR>
							<TD class="submenu_title" colspan=2><?php echo $this->_tpl_vars['LDMedLab']; ?>
</TD>
						</tr>
						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDMedLabTestRequest']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestRequestChemLabTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDMedLabTestReception']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestReceptionTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDSeeData']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDSeeLabData']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<!--
						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDNewData']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDEnterLabData']; ?>
</TD>
						</tr>
-->						

						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDEditData']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDEditLabData']; ?>
</TD>
						</tr>


					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE>
			<p>
			<!--			
			MEROTECH
			Commented out for selian town clinic by Alexander Irro
			
			
<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">
						<TR>
							<TD class="submenu_title" colspan=2><?php echo $this->_tpl_vars['LDPathLab']; ?>
</TD>
						</tr>
						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDPathLabTestRequest']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestRequestPathoTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDPathLabTestReception']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestReceptionTxt']; ?>
</TD>
						</tr>

					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE>
			<p>
			<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">
						<TR>
							<TD class="submenu_title" colspan=2><?php echo $this->_tpl_vars['LDBacLab']; ?>
</TD>
						</tr>
						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDBacLabTestRequest']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestRequestBacterioTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDBacLabTestReception']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestReceptionTxt']; ?>
</TD>
						</tr>

					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE> -->
			<p>
			<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">
						<TR>
							<TD class="submenu_title" colspan=2><?php echo $this->_tpl_vars['LDBloodBank']; ?>
</TD>
						</tr>
						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDBloodRequest']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDBloodRequestTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><nobr><?php echo $this->_tpl_vars['LDBloodTestReception']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestReceptionTxt']; ?>
</TD>
						</tr>

					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE> 
			<p>
			<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">
						<TR>
							<TD class="submenu_title" colspan=2><?php echo $this->_tpl_vars['LDAdministration']; ?>
</TD>
						</tr>
						<TR>
							<TD class="submenu_item" width=35% ><nobr><?php echo $this->_tpl_vars['LDTestParameters']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestParametersTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>						
						<TR>
							<TD class="submenu_item" width=35% ><nobr><?php echo $this->_tpl_vars['LDTestGroups']; ?>
</nobr></TD>
							<TD><?php echo $this->_tpl_vars['LDTestGroupsTxt']; ?>
</TD>
						</tr>
					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE>
			<p>
			<a href="<?php echo $this->_tpl_vars['breakfile']; ?>
"><img <?php echo $this->_tpl_vars['gifClose2']; ?>
 alt="<?php echo $this->_tpl_vars['LDCloseAlt']; ?>
" <?php echo $this->_tpl_vars['dhtml']; ?>
></a>
			<p>
			</blockquote>