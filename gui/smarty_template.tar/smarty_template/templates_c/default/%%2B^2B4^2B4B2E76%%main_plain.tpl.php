<?php /* Smarty version 2.6.22, created on 2011-08-25 08:59:12
         compiled from medocs/main_plain.tpl */ ?>
<table width="100%" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "medocs/tabs.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></td>
    </tr>
    <tr>
      <td>
			&nbsp;<br>
			<?php echo $this->_tpl_vars['sMainDataBlock']; ?>


	  </td>
    </tr>
  </tbody>
</table>