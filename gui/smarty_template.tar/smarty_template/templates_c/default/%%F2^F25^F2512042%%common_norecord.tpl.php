<?php /* Smarty version 2.6.22, created on 2012-08-11 23:17:06
         compiled from registration_admission/common_norecord.tpl */ ?>
						<table border=0>

							<tr>
								<td><?php echo $this->_tpl_vars['sMascotImg']; ?>
</td>
								<td class="prompt">
									<?php echo $this->_tpl_vars['norecordyet']; ?>

								</td>
							</tr>
							<tr>
								<td>&nbsp;</td>
								<td>
									<?php echo $this->_tpl_vars['sPromptIcon']; ?>
 &nbsp; <?php echo $this->_tpl_vars['sPromptLink']; ?>
 &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->_tpl_vars['sPromptIcon']; ?>
 &nbsp; <?php echo $this->_tpl_vars['sPromptLinkEdit']; ?>


								</td>
							</tr>

						</table>