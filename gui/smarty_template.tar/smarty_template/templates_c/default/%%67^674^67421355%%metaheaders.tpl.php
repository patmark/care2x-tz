<?php /* Smarty version 2.6.22, created on 2013-11-22 10:18:17
         compiled from common/metaheaders.tpl */ ?>
<meta name="Description" content="Hospital and Healthcare Integrated Information System - CARE2x">
<meta name="Author" content="Elpidio Latorilla">
<meta name="Generator" content="various: Quanta, AceHTML 4 Freeware, NuSphere, PHP Coder">
<?php if ($this->_tpl_vars['sReloadPage']): ?>
	<meta http-equiv="refresh" content="<?php echo $this->_tpl_vars['sReloadDelay']; ?>
; URL=<?php echo $this->_tpl_vars['sReloadTarget']; ?>
">
<?php endif; ?>
<?php echo $this->_tpl_vars['sExtraMetaString']; ?>