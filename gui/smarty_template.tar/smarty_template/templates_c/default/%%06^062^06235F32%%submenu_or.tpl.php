<?php /* Smarty version 2.6.22, created on 2012-08-22 17:44:52
         compiled from or/submenu_or.tpl */ ?>
			<blockquote>
		 	<div class="prompt"><?php echo $this->_tpl_vars['LDOrDocs']; ?>
</div>
			<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDOrDocument']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDOrDocumentTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDQviewDocs']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDQviewTxtDocs']; ?>
</TD>
						</tr>

					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE>

			<p>
		 	<div class="prompt"><?php echo $this->_tpl_vars['LDOrNursing']; ?>
</div>
			<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDOrLogBook']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDOrLogBookTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDORNOCQuickView']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDQviewTxtNurse']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDORNOCScheduler']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDDutyPlanTxt']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDOnCallDuty']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDOnCallDutyTxt']; ?>
</TD>
						</tr>

					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE>

			<p>
		 	<div class="prompt"><?php echo $this->_tpl_vars['LDORAnesthesia']; ?>
</div>
			<TABLE cellSpacing=0  width=600 class="submenu_frame" cellpadding="0">
			<TBODY>
			<TR>
				<TD>
					<TABLE cellSpacing=1 cellPadding=3 width=600>
					<TBODY class="submenu">

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDORAnaQuickView']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDQviewTxtAna']; ?>
</TD>
						</tr>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/submenu_row_spacer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

						<TR>
							<TD class="submenu_item" width=35%><?php echo $this->_tpl_vars['LDORAnaNOCScheduler']; ?>
</TD>
							<TD><?php echo $this->_tpl_vars['LDDutyPlanTxt']; ?>
</TD>
						</tr>

					</TBODY>
					</TABLE>
				</TD>
			</TR>
			</TBODY>
			</TABLE>
			
			<?php echo $this->_tpl_vars['sOnHoverMenu']; ?>


			<p>
			<a href="<?php echo $this->_tpl_vars['breakfile']; ?>
"><img <?php echo $this->_tpl_vars['gifClose2']; ?>
 alt="<?php echo $this->_tpl_vars['LDCloseAlt']; ?>
" <?php echo $this->_tpl_vars['dhtml']; ?>
></a>
			<p>
			</blockquote>