<?php /* Smarty version 2.6.22, created on 2013-11-22 10:18:24
         compiled from common/footer.tpl */ ?>
<!--  <?php echo $this->_tpl_vars['SmartyLogo']; ?>
 -->
</BODY>
</HTML>