<?php /* Smarty version 2.6.22, created on 2011-09-12 16:25:51
         compiled from cafeteria/cafenews_list.tpl */ ?>
<table width=100%>
	
	<tr valign=top>
		<td>
			<?php echo $this->_tpl_vars['sNews_1']; ?>

			<hr>
		</td>
	</tr>

	<tr valign=top>
	<td>
			<?php echo $this->_tpl_vars['sNews_2']; ?>

			<hr>
		</td>
	</tr>

	<tr valign=top>
		<td>
			<?php echo $this->_tpl_vars['sNews_3']; ?>

			<hr>
		</td>
	</tr>
	
</table>