<?php /* Smarty version 2.6.0, created on 2009-01-13 00:56:53
         compiled from news/headline_newslist.tpl */ ?>
<table width=100%>
	<tr>
		<td>
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "news/headline_titleblock.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</td>
	</tr>

	<tr valign=top>
		<td>
			<?php echo $this->_tpl_vars['sNews_1']; ?>

			<hr>
		</td>
	</tr>

	<tr valign=top>
	<td>
			<?php echo $this->_tpl_vars['sNews_2']; ?>

			<hr>
		</td>
	</tr>

	<tr valign=top>
		<td>
			<?php echo $this->_tpl_vars['sNews_3']; ?>

			<hr>
		</td>
	</tr>
	
</table>