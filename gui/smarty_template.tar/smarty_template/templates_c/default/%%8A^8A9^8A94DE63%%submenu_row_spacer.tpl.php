<?php /* Smarty version 2.6.22, created on 2012-08-11 23:22:31
         compiled from common/submenu_row_spacer.tpl */ ?>
<TR  height=1>
	<TD colSpan=3 class="vspace"><IMG height=1 src="../../gui/img/common/default/pixel.gif" width=5></TD>
</TR>