<?php /* Smarty version 2.6.0, created on 2009-01-13 00:55:06
         compiled from common/metaheaders.tpl */ ?>
<meta name="Description" content="Hospital and Healthcare Integrated Information System - CARE2x">
<meta name="Author" content="Elpidio Latorilla">
<meta name="Generator" content="various: Quanta, AceHTML 4 Freeware, NuSphere, PHP Coder">
<?php if ($this->_tpl_vars['sReloadPage']): ?>
	<meta http-equiv="refresh" content="<?php echo $this->_tpl_vars['sReloadDelay']; ?>
; URL=<?php echo $this->_tpl_vars['sReloadTarget']; ?>
">
<?php endif;  echo $this->_tpl_vars['sExtraMetaString']; ?>