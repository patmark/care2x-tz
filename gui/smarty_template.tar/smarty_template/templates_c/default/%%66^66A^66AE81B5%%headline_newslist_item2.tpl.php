<?php /* Smarty version 2.6.22, created on 2012-08-11 20:12:29
         compiled from news/headline_newslist_item2.tpl */ ?>

<img <?php echo $this->_tpl_vars['sHeadlineImg']; ?>
 align="right" border=0 hspace=10 <?php echo $this->_tpl_vars['sImgWidth']; ?>
>
<?php echo $this->_tpl_vars['sHeadlineItemTitle']; ?>

<br>
<?php echo $this->_tpl_vars['sPreface']; ?>

<p>
<?php echo $this->_tpl_vars['sNewsPreview']; ?>

<br>
<font size=1><?php echo $this->_tpl_vars['sEditorLink']; ?>
</font>