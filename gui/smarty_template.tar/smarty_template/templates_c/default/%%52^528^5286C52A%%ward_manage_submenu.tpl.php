<?php /* Smarty version 2.6.22, created on 2011-09-22 17:51:59
         compiled from nursing/ward_manage_submenu.tpl */ ?>

<ul>
<table border=0 cellpadding=5>
  <tbody>
    <tr>
      <td bgcolor="#0066aa"><font color="white"><b><?php echo $this->_tpl_vars['LDProfile']; ?>
</b></font></td>
    </tr>
    <tr>
      <td>
	  <?php echo $this->_tpl_vars['sCreate']; ?>
<br>
	  &nbsp;<?php echo $this->_tpl_vars['LDNewStation']; ?>
<p>
	  <?php echo $this->_tpl_vars['sShowStationData']; ?>
<br>
		<?php echo $this->_tpl_vars['LDShowStationDataTxt']; ?>
<p>
	  </td>
    </tr>
  </tbody>
</table>
<p>
<?php echo $this->_tpl_vars['sCancel']; ?>

</p>
</ul>