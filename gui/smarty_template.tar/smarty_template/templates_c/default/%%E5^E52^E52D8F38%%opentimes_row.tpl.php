<?php /* Smarty version 2.6.22, created on 2011-10-04 10:32:42
         compiled from common/opentimes_row.tpl */ ?>

<tr bgcolor=#ffffff>
	<td><?php echo $this->_tpl_vars['sOpenDay']; ?>
</td>
	<td><?php echo $this->_tpl_vars['sOpenTimes']; ?>
</td>
	<td><?php echo $this->_tpl_vars['sVisitTimes']; ?>
</td>
</tr>