<?php /* Smarty version 2.6.0, created on 2009-03-03 19:19:01
         compiled from registration_admission/reg_row.tpl */ ?>
<tr>
  <td class="reg_item" <?php echo $this->_tpl_vars['sColSpan1']; ?>
><?php echo $this->_tpl_vars['sItem']; ?>
</td>
  <td class="reg_input" <?php echo $this->_tpl_vars['sColSpan2']; ?>
><?php echo $this->_tpl_vars['sInput']; ?>
</td>
</tr>