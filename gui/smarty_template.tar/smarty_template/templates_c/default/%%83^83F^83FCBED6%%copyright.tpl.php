<?php /* Smarty version 2.6.22, created on 2012-08-11 20:12:29
         compiled from common/copyright.tpl */ ?>
<table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#cfcfcf">
<tr>
<td align="center">
  <table width="100%" bgcolor="#ffffff" cellspacing=0 cellpadding=5>
   <tr>
   	<td>
	    <?php echo $this->_tpl_vars['sCopyright']; ?>

	    <font size=1 face="verdana,arial">
	    <?php echo $this->_tpl_vars['sPageTime']; ?>

	    </font>
    </td>
   <tr>
  </table>
</td>
</tr>
</table>