<?php
/**
* This is the tag file for the smarty template
*/

$sTemplateName = "Mac 1";
$sTemplateDirectory ="mac1";
$sTemplateDescription = "Page title on top center with grooved gray/white background, return & help buttons on top left, close button on top right. 
Main frame's elements  will be displayed at the center.";
$sTemplateScreenShot = "";

?>
