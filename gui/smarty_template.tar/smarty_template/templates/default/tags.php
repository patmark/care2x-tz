<?php
/**
* This is the tag file for the smarty template
*/

$sTemplateName = "System default";
$sTemplateDirectory ="default";
$sTemplateDescription = "Default templates. Title on top left, control buttons on top right, etc. 
The system will use these templates in case the chosen template theme is not available.";
$sTemplateScreenShot = "";

?>
