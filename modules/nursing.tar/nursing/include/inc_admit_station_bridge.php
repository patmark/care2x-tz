<?php
if($_SESSION['sess_parent_mod']=='admission') {
	$local_user='aufnahme_user';
}else{
	$local_user='ck_pflege_user';
}
?>
