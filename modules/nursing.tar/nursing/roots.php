<?php
$root_path='../../';
$top_dir='modules/nursing/';
# Root path used in templates
$TP_root_path='../..';
?>
